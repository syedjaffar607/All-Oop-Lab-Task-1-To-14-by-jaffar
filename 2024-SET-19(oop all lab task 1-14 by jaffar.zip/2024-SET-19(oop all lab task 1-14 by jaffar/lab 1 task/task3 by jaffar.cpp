#include<iostream>
using namespace std;

struct student{
	string firstname;
	string lastname;
	int rollnumber;
	float marks;
	
	void displaystudentinfo(){
		cout<<"full name:"<<firstname<<" "<<lastname<<endl;
		cout<<"marks:"<<marks<<endl;
	}
};
int main(){
	student *ptr= new student;
	
	cout<<"enter first name:";
	cin>>ptr->firstname;
	cout<<"enterlast name:";
	cin>>ptr->lastname;
	cout<<"enter roll number:";
	cin>>ptr->rollnumber;
	cout<<"enter marks:";
	cin>>ptr->marks;
	ptr->displaystudentinfo();
	delete ptr;
	return 0;
}
