#include<iostream>
using namespace std;

struct student{
	string firstname;
	string lastname;
	int rollnumber;
	float marks;
	void displaystudentinfo(){
		cout<<"full name:"<<firstname<<" "<<lastname<<endl;
		cout<<"marks:"<<marks<<endl;
	}
};
int main(){
	student s1;
	
	s1.firstname="zahra";
	s1.lastname="mukhtar";
	s1.rollnumber= 102;
	s1.marks= 77.5;
	
	s1.displaystudentinfo();
	
	return 0;
}
