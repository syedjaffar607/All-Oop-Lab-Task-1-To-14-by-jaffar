#include<iostream>
using namespace std;
class Student
{
	public:
		string Name;
		int Rollnumber;
		float Marks;
		
	void getData(){
		cout<<"Enter Name:"<<endl;
		cin>>Name;
		cout<<"Enter Rollnumber:"<<endl;
		cin>>Rollnumber;
		cout<<"Enter Marks:"<<endl;
		cin>>Marks;
	}
	void displayData(){
		cout<<"Student Name"<<Name<<endl;
		cout<<"Student Rollnumber"<<Rollnumber<<endl;
		cout<<"Student Marks"<<Marks<<endl;
	}
};
int main(){
	Student S1;
	S1.getData();
	S1.displayData();
	
	return 0;
};
