#include <iostream>
using namespace std;

class Voter {
public:
    string name;
    int age;
    void getData();
    bool isEligible();
};

void Voter::getData() {
    cout << "Enter Name: ";
    cin >> name;

    cout << "Enter Age: ";
    cin >> age;
}

bool Voter::isEligible() {
    return age > 18;
}

int main() {
    Voter v1;
    v1.getData();

    if (v1.isEligible())
        cout << "\nYou are eligible to vote." << endl;
    else
        cout << "\nYou are NOT eligible to vote." << endl;

    return 0;
}
