#include <iostream>
using namespace std;

class Calculator {
public:
    float num1, num2;
    void setNumbers();
    float add();
    float subtract();
    float multiply();
    float divide();
};

void Calculator::setNumbers() {
    cout << "Enter first number: ";
    cin >> num1;

    cout << "Enter second number: ";
    cin >> num2;
}

float Calculator::add() {
    return num1 + num2;
}

float Calculator::subtract() {
    return num1 - num2;
}

float Calculator::multiply() {
    return num1 * num2;
}

float Calculator::divide() {
    if (num2 != 0)
        return num1 / num2;
    else {
        cout << "Error! Division by zero." << endl;
        return 0;
    }
}

int main() {
    Calculator c1;
    int choice;

    c1.setNumbers();

    cout << "\nChoose Operation:" << endl;
    cout << "1. Add\n2. Subtract\n3. Multiply\n4. Divide\n";
    cout << "Enter choice: ";
    cin >> choice;

    switch (choice) {
        case 1:
            cout << "Result: " << c1.add();
            break;
        case 2:
            cout << "Result: " << c1.subtract();
            break;
        case 3:
            cout << "Result: " << c1.multiply();
            break;
        case 4:
            cout << "Result: " << c1.divide();
            break;
        default:
            cout << "Invalid choice!";
    }

    return 0;
}
