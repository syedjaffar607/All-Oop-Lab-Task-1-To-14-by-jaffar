#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ofstream file("students.txt");

    file << "Name: Ahmed" << endl;
    file << "Roll No: 10" << endl;

    file << "Name: zia" << endl;
    file << "Roll No: 07" << endl;

    file << "Name: faizan" << endl;
    file << "Roll No: 09" << endl;

    file.close();
    
    ifstream readFile("students.txt");

    string line;

    cout << "Student Details:" << endl;

    while (getline(readFile, line))
    {
        cout << line << endl;
    }

    readFile.close();

    return 0;
}