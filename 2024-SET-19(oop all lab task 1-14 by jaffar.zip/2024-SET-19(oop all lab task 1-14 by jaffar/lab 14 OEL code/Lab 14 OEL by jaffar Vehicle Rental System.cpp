#include <iostream>
#include <vector>
#include <memory>
#include <iomanip>
#include <string>
using namespace std;

// Base class
class Vehicle {
private:
    int id;
    string model;
    double dailyRate;
    bool available;

public:
    Vehicle(int id, const string& model, double rate)
        : id(id), model(model), dailyRate(rate), available(true) {}

    virtual ~Vehicle() = default;

    int getId() const { return id; }
    string getModel() const { return model; }
    double getDailyRate() const { return dailyRate; }
    bool isAvailable() const { return available; }

    void setAvailable(bool status) { available = status; }

    // Runtime polymorphism
    virtual string getType() const = 0;
    virtual double calculateCost(int days) const {
        return dailyRate * days;
    }

    virtual void display() const {
        cout << id << " | " << getType() << " | "
             << model << " | Rs. " << dailyRate
             << "/day | " << (available ? "Available" : "Rented") << '\n';
    }
};

// Derived class: Car
class Car : public Vehicle {
private:
    int seats;

public:
    Car(int id, const string& model, double rate, int seats)
        : Vehicle(id, model, rate), seats(seats) {}

    string getType() const override { return "Car"; }

    double calculateCost(int days) const override {
        return getDailyRate() * days;
    }
};

// Derived class: Motorbike
class Motorbike : public Vehicle {
public:
    Motorbike(int id, const string& model, double rate)
        : Vehicle(id, model, rate) {}

    string getType() const override { return "Motorbike"; }

    double calculateCost(int days) const override {
        double cost = getDailyRate() * days;

        // 10% discount for rentals longer than 7 days
        if (days > 7)
            cost *= 0.90;

        return cost;
    }
};

// Derived class: Truck
class Truck : public Vehicle {
private:
    double payloadCapacity;

public:
    Truck(int id, const string& model, double rate, double payload)
        : Vehicle(id, model, rate), payloadCapacity(payload) {}

    string getType() const override { return "Truck"; }

    double calculateCost(int days) const override {
        // 20% surcharge
        return getDailyRate() * days * 1.20;
    }
};

// Customer class
class Customer {
private:
    int customerId;
    string name;
    bool hasActiveRental;

public:
    Customer(int id, const string& name)
        : customerId(id), name(name), hasActiveRental(false) {}

    int getId() const { return customerId; }
    string getName() const { return name; }
    bool hasRental() const { return hasActiveRental; }

    void setActiveRental(bool status) {
        hasActiveRental = status;
    }
};

// Rental class
class Rental {
private:
    int customerId;
    int vehicleId;
    int days;
    double cost;
    bool closed;

public:
    Rental(int customerId, int vehicleId, int days, double cost)
        : customerId(customerId), vehicleId(vehicleId),
          days(days), cost(cost), closed(false) {}

    int getCustomerId() const { return customerId; }
    int getVehicleId() const { return vehicleId; }
    bool isClosed() const { return closed; }

    void closeRental() { closed = true; }

    void display() const {
        cout << "Customer ID: " << customerId
             << " | Vehicle ID: " << vehicleId
             << " | Days: " << days
             << " | Cost: Rs. " << fixed << setprecision(2) << cost
             << " | " << (closed ? "Closed" : "Active") << '\n';
    }
};

// Central system manages vehicles, customers and rental records
class RentalSystem {
private:
    vector<unique_ptr<Vehicle>> vehicles;
    vector<Customer> customers;
    vector<Rental> rentals;

    Vehicle* findVehicle(int id) {
        for (auto& vehicle : vehicles) {
            if (vehicle->getId() == id)
                return vehicle.get();
        }
        return nullptr;
    }

    Customer* findCustomer(int id) {
        for (auto& customer : customers) {
            if (customer.getId() == id)
                return &customer;
        }
        return nullptr;
    }

public:
    void addVehicle(unique_ptr<Vehicle> vehicle) {
        vehicles.push_back(move(vehicle));
    }

    void registerCustomer(const Customer& customer) {
        customers.push_back(customer);
    }

    bool rentVehicle(int customerId, int vehicleId, int days) {
        Customer* customer = findCustomer(customerId);
        Vehicle* vehicle = findVehicle(vehicleId);

        if (!customer || !vehicle || days <= 0)
            return false;

        if (customer->hasRental() || !vehicle->isAvailable())
            return false;

        // Virtual function call: runtime polymorphism
        double cost = vehicle->calculateCost(days);

        vehicle->setAvailable(false);
        customer->setActiveRental(true);
        rentals.emplace_back(customerId, vehicleId, days, cost);

        cout << "Rental processed successfully.\n";
        return true;
    }

    bool returnVehicle(int customerId, int vehicleId) {
        Customer* customer = findCustomer(customerId);
        Vehicle* vehicle = findVehicle(vehicleId);

        if (!customer || !vehicle)
            return false;

        for (auto& rental : rentals) {
            if (rental.getCustomerId() == customerId &&
                rental.getVehicleId() == vehicleId &&
                !rental.isClosed()) {

                rental.closeRental();
                vehicle->setAvailable(true);
                customer->setActiveRental(false);

                cout << "Vehicle returned successfully.\n";
                return true;
            }
        }

        return false;
    }

    void printSummary() const {
        int available = 0;
        int rented = 0;

        cout << "\n========== VEHICLE FLEET ==========\n";
        for (const auto& vehicle : vehicles) {
            vehicle->display();

            if (vehicle->isAvailable())
                available++;
            else
                rented++;
        }

        cout << "\n========== ACTIVE RENTALS ==========\n";
        bool found = false;

        for (const auto& rental : rentals) {
            if (!rental.isClosed()) {
                rental.display();
                found = true;
            }
        }

        if (!found)
            cout << "No active rentals.\n";

        cout << "\nAvailable Vehicles: " << available << '\n';
        cout << "Rented Vehicles: " << rented << '\n';
    }
};

int main() {
    RentalSystem system;

    // Add at least 3 vehicles
    system.addVehicle(make_unique<Car>(1, "Toyota Corolla", 5000, 5));
    system.addVehicle(make_unique<Motorbike>(2, "Honda CD 70", 1500));
    system.addVehicle(make_unique<Truck>(3, "Isuzu Truck", 10000, 5.0));

    // Register 2 customers
    system.registerCustomer(Customer(101, "Ali"));
    system.registerCustomer(Customer(102, "Ahmed"));

    // Process 2 rentals
    system.rentVehicle(101, 1, 5);   // Car: 5000 x 5 = 25000
    system.rentVehicle(102, 3, 3);   // Truck: 10000 x 3 + 20% = 36000

    // Return one vehicle
    system.returnVehicle(101, 1);

    // Print final summary
    system.printSummary();

    return 0;
}
